import pytest
from app.services.ai_service import AIService
from app.models.business import Business
from unittest.mock import patch

@pytest.mark.asyncio
async def test_generate_response():
    with patch('app.services.ai_service.APIClient.get_model_response') as mock_get_response:
        mock_get_response.return_value = "This is a test response"
        
        ai_service = AIService()
        response = await ai_service.generate_response("Test query", 1)
        
        assert response == "This is a test response"
        mock_get_response.assert_called_once()

@pytest.mark.asyncio
async def test_escalation_triggered():
    ai_service = AIService()
    
    assert ai_service.is_escalation_triggered("urgent help needed", "Short response")
    assert ai_service.is_escalation_triggered("normal query", "A very long response " * 20)
    assert not ai_service.is_escalation_triggered("normal query", "Short response")

