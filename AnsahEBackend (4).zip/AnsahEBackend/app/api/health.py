from fastapi import APIRouter
from app.core.cache import cache
from app.db.session import SessionLocal

router = APIRouter()

@router.get("/health")
async def health_check():
    health = {"status": "healthy", "components": {}}
    
    # Database check
    try:
        db = SessionLocal()
        db.execute("SELECT 1")
        health["components"]["database"] = "healthy"
    except Exception as e:
        health["components"]["database"] = f"unhealthy: {str(e)}"
    
    # Redis check
    try:
        cache.set("health_check", "1")
        assert cache.get("health_check") == "1"
        health["components"]["redis"] = "healthy"
    except Exception as e:
        health["components"]["redis"] = f"unhealthy: {str(e)}"
    
    return health

