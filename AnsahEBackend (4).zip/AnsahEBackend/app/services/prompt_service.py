from app.models.business import Business
from app.core.config import settings
import jinja2

class PromptService:
    def __init__(self):
        self.template_env = jinja2.Environment(
            loader=jinja2.FileSystemLoader(settings.TEMPLATE_DIR)
        )

    def generate_prompt(self, business: Business, query: str) -> str:
        template = self.template_env.get_template(f"{business.response_tone}_template.j2")
        return template.render(
            business_name=business.name,
            faq_url=business.faq_url,
            shipping_policy_url=business.shipping_policy_url,
            return_policy_url=business.return_policy_url,
            refund_policy_url=business.refund_policy_url,
            query=query
        )

prompt_service = PromptService()

