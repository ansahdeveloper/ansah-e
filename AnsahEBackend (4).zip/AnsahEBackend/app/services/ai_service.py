from app.integrations.ticketing import TicketingAPI
from app.services.prompt_service import PromptService
from fastapi import HTTPException
from app.models.business import Business
from app.integrations.api_client import APIClient
from app.core.config import settings
import asyncio

class AIService:
    def __init__(self, server_type: str = 'cloud'):
        self.server_type = server_type
        self.api_client = APIClient(server_type)
        self.ticketing_api = TicketingAPI()
        self.prompt_service = PromptService()

    async def generate_response(self, user_query: str, business_id: int, conversation_id: str = None):
        context = self.get_conversation_context(conversation_id) if conversation_id else []
        context.append(f"User: {user_query}")
    
        while len(" ".join(context)) > 1000:
            context.pop(0)
    
        business = await self.get_business(business_id)
        prompt = self.prompt_service.generate_prompt(business, "\n".join(context))
    
        response = await self.api_client.get_model_response(prompt, self.server_type)
    
        context.append(f"AI: {response}")
        self.save_conversation_context(conversation_id, context)
    
        if self.is_escalation_triggered(user_query, response):
            await self.handle_escalation(user_query, response, business_id)
    
        return response

    def get_conversation_context(self, conversation_id: str):
        return settings.cache.get(f"conversation:{conversation_id}") or []

    def save_conversation_context(self, conversation_id: str, context: list):
        settings.cache.set(f"conversation:{conversation_id}", context, expiration=3600)

    async def get_business(self, business_id: int):
        return await Business.get(business_id)

    def is_escalation_triggered(self, query, response):
        escalation_keywords = ['urgent', 'immediate', 'escalate', 'manager']
        return any(keyword in query.lower() for keyword in escalation_keywords) or len(response.split()) > 100

    async def handle_escalation(self, query, response, business_id):
        ticket_data = {
            'issue': query,
            'escalation_level': 'high',
            'user_id': business_id,
            'message': response,
            'status': 'escalated'
        }
        await self.ticketing_api.create_ticket(ticket_data)

