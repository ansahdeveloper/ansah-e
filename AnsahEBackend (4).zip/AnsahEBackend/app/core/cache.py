from redis import Redis
from app.core.config import settings
import json

class Cache:
    def __init__(self):
        self.redis = Redis.from_url(settings.REDIS_URL)

    def set(self, key: str, value: any, expiration: int = 3600):
        return self.redis.set(key, json.dumps(value), ex=expiration)

    def get(self, key: str):
        value = self.redis.get(key)
        return json.loads(value) if value else None

    def delete(self, key: str):
        return self.redis.delete(key)

cache = Cache()

