from fastapi import HTTPException
from tenacity import retry, stop_after_attempt, wait_exponential

class AppException(Exception):
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail

def handle_app_exception(exc: AppException):
    raise HTTPException(status_code=exc.status_code, detail=exc.detail)

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
async def retry_async(func, *args, **kwargs):
    return await func(*args, **kwargs)

