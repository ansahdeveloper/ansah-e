from pydantic import BaseModel, validator
import bleach

ALLOWED_TAGS = ['p', 'br', 'strong', 'em', 'u', 'ol', 'ul', 'li']
ALLOWED_ATTRIBUTES = {'*': ['class']}

class QueryModel(BaseModel):
    business_id: int
    user_query: str

    @validator('user_query')
    def sanitize_query(cls, v):
        return bleach.clean(v, tags=ALLOWED_TAGS, attributes=ALLOWED_ATTRIBUTES, strip=True)

