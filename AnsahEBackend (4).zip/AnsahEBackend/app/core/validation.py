from pydantic import BaseModel, validator
import bleach

class QueryModel(BaseModel):
    business_id: int
    user_query: str

    @validator('user_query')
    def sanitize_query(cls, v):
        return bleach.clean(v)

