from circuitbreaker import circuit

@circuit(failure_threshold=5, recovery_timeout=30)
async def call_external_service(service_func, *args, **kwargs):
    return await service_func(*args, **kwargs)

