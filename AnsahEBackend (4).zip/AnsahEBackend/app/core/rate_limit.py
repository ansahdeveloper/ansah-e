from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from app.core.cache import cache

class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        client_ip = request.client.host
        key = f"rate_limit:{client_ip}"
        
        if cache.get(key):
            raise HTTPException(status_code=429, detail="Rate limit exceeded")
        
        cache.set(key, "1", expiration=60)  # 1 request per minute
        
        response = await call_next(request)
        return response

