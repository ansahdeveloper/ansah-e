from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from app.core.cache import cache

class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        api_key = request.headers.get("X-API-Key")
        if not api_key:
            raise HTTPException(status_code=400, detail="API Key required")
        
        key = f"rate_limit:{api_key}"
        
        if cache.get(key):
            raise HTTPException(status_code=429, detail="Rate limit exceeded")
        
        cache.set(key, "1", expiration=60)  # 1 request per minute per API key
        
        response = await call_next(request)
        return response

