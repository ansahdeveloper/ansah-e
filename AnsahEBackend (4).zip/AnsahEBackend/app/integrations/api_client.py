import httpx
from app.core.config import settings

class APIClient:
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=settings.API_TIMEOUT)

    async def get(self, url: str, params: dict = None, headers: dict = None):
        response = await self.client.get(url, params=params, headers=headers)
        response.raise_for_status()
        return response.json()

    async def post(self, url: str, data: dict = None, json: dict = None, headers: dict = None):
        response = await self.client.post(url, data=data, json=json, headers=headers)
        response.raise_for_status()
        return response.json()

api_client = APIClient()

