from .api_client import api_client

class ZendeskAPI:
    BASE_URL = "https://your-domain.zendesk.com/api/v2"

    async def get_tickets(self):
        return await api_client.get(f"{self.BASE_URL}/tickets.json")

class FreshdeskAPI:
    BASE_URL = "https://your-domain.freshdesk.com/api/v2"

    async def get_tickets(self):
        return await api_client.get(f"{self.BASE_URL}/tickets")

# Add other ticketing APIs here

