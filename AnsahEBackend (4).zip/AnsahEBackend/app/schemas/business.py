from pydantic import BaseModel, EmailStr, HttpUrl, validator
from typing import Optional, List

class BusinessBase(BaseModel):
    name: str
    contact_email: EmailStr
    faq_url: HttpUrl
    shipping_policy_url: HttpUrl
    return_policy_url: HttpUrl
    refund_policy_url: HttpUrl
    business_phone: Optional[str] = None
    social_media_links: Optional[List[HttpUrl]] = None
    custom_api_url: Optional[HttpUrl] = None
    response_tone: str

    @validator('response_tone')
    def validate_response_tone(cls, v):
        allowed_tones = ['friendly', 'professional', 'empathetic']
        if v not in allowed_tones:
            raise ValueError(f'response_tone must be one of {allowed_tones}')
        return v

class BusinessCreate(BusinessBase):
    pass

class BusinessUpdate(BusinessBase):
    pass

class BusinessInDBBase(BusinessBase):
    id: int

    class Config:
        orm_mode = True

class Business(BusinessInDBBase):
    pass

class BusinessInDB(BusinessInDBBase):
    pass

