import os
import json

def setup_deployment():
    print("Welcome to Ansah E Setup!")
    print("Please choose your deployment type:")
    print("1. Local Deployment")
    print("2. Cloud Deployment")

    choice = input("Enter your choice (1 or 2): ")

    if choice == "1":
        server_type = "local"
        api_url = input("Enter your local API URL (default: http://localhost:5000): ") or "http://localhost:5000"
    elif choice == "2":
        server_type = "cloud"
        api_url = input("Enter your cloud API URL: ")
    else:
        print("Invalid choice. Exiting setup.")
        return

    config = {
        "server_type": server_type,
        "api_url": api_url
    }

    with open("config.json", "w") as f:
        json.dump(config, f)

    print(f"Setup complete! Configuration saved to config.json")
    print(f"Server Type: {server_type}")
    print(f"API URL: {api_url}")

if __name__ == "__main__":
    setup_deployment()

