const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const axios = require('axios');

function createWindow() {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });

  win.loadFile('index.html');
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

ipcMain.handle('fetch-response', async (event, { user_query, business_id }) => {
  try {
    const response = await axios.post('http://localhost:8000/desktop/generate_response', {
      user_query,
      business_id,
    });
    return response.data.response;
  } catch (error) {
    console.error('Error fetching response:', error);
    return 'An error occurred while fetching the response.';
  }
});

