from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import onboarding, query, status, integrations, policies
from app.database import engine, Base

app = FastAPI(title="Ansah E Backend")

# CORS middleware setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust this in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create database tables
Base.metadata.create_all(bind=engine)

# Include routers
app.include_router(onboarding.router)
app.include_router(query.router)
app.include_router(status.router)
app.include_router(integrations.router)
app.include_router(policies.router)

@app.get("/")
async def root():
    return {"message": "Welcome to Ansah E Backend"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

