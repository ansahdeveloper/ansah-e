import pytest
from app.services.ai_service import AIService
from app.models.business import Business
from app.db.session import SessionLocal

@pytest.mark.asyncio
async def test_ai_service_integration():
    db = SessionLocal()
    try:
        # Create a test business
        business = Business(name="Test Business", response_tone="professional")
        db.add(business)
        db.commit()

        ai_service = AIService()
        response = await ai_service.generate_response("Test query", business.id)

        assert response, "Response should not be empty"
        assert len(response.split()) <= 100, "Response should not exceed 100 words"
    finally:
        db.close()

