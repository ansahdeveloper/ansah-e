from app.integrations.ticketing import TicketingAPI
from app.services.prompt_service import PromptService
from app.models.business import Business
from app.integrations.api_client import APIClient
from app.core.error_handling import retry_async, AppException
from app.core.logging import logger
from app.core.cache import cache
from app.core.circuit_breaker import call_external_service
import asyncio

class AIService:
    def __init__(self):
        self.api_client = APIClient()
        self.ticketing_api = TicketingAPI()
        self.prompt_service = PromptService()

    async def generate_response(self, user_query: str, business_id: int, conversation_id: str = None):
        context = self.get_conversation_context(conversation_id) if conversation_id else []
        context.append(f"User: {user_query}")
    
        # Truncate context if it's too long
        while len(" ".join(context)) > 1000:  # Adjust based on model's context window
            context.pop(0)
    
        prompt = self.prompt_service.generate_prompt(self.get_business(business_id), "\n".join(context))
    
        response = await self.get_model_response(prompt)
    
        context.append(f"AI: {response}")
        self.save_conversation_context(conversation_id, context)
    
        return response

    def get_conversation_context(self, conversation_id: str):
        return cache.get(f"conversation:{conversation_id}") or []

    def save_conversation_context(self, conversation_id: str, context: list):
        cache.set(f"conversation:{conversation_id}", context, expiration=3600)  # Store for 1 hour

    def get_business(self, business_id: int):
        return asyncio.run(retry_async(Business.get, business_id))


    #async def generate_response(self, user_query: str, business_id: int):
    #    try:
    #        # Try to get cached response
    #        cache_key = f"response:{business_id}:{user_query}"
    #        cached_response = cache.get(cache_key)
    #        if cached_response:
    #            logger.info(f"Cache hit for query: {user_query}")
    #            return cached_response

    #        # Fetch business-specific data
    #        business = await retry_async(Business.get, business_id)
    #        response_tone = business.response_tone or 'professional'

    #        # Generate dynamic prompt
    #        prompt = self.prompt_service.generate_prompt(response_tone, user_query, business)
            
    #        # Get model response with circuit breaker
    #        response = await call_external_service(self.api_client.get_model_response, prompt)
            
    #        # Check for escalation
    #        if self.is_escalation_triggered(user_query, response):
    #            await self.handle_escalation(user_query, response, business_id)
            
    #        # Cache the response
    #        cache.set(cache_key, response, expiration=3600)  # Cache for 1 hour
            
    #        return response

    #    except AppException as e:
    #        logger.error(f"Application error: {str(e)}")
    #        raise
    #    except Exception as e:
    #        logger.error(f"Unexpected error: {str(e)}")
    #        raise AppException(status_code=500, detail="An unexpected error occurred")

    def is_escalation_triggered(self, query, response):
        escalation_keywords = ['urgent', 'immediate', 'escalate', 'manager']
        return any(keyword in query.lower() for keyword in escalation_keywords) or len(response.split()) > 100

    async def handle_escalation(self, query, response, business_id):
        ticket_data = {
            'issue': query,
            'escalation_level': 'high',
            'user_id': business_id,
            'message': response,
            'status': 'escalated'
        }
        await retry_async(self.ticketing_api.create_ticket, ticket_data)
        logger.info(f"Escalation ticket created for business {business_id}")

    async def get_model_response(self, prompt: str):
        model_params = {
            "temperature": 0.7,
            "max_tokens": 500,
            "top_p": 0.9,
        }
        return await retry_async(self.api_client.post, "https://mistral-7b-api.com/generate", json={"prompt": prompt, **model_params})

