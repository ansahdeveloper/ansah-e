from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory
from langchain.llms import OpenAI
from app.integrations.api_client import APIClient
from app.core.config import settings
from app.core.logging import logger
from langgraph.graph import Graph

class CustomerSupportChain:
    def __init__(self):
        self.llm = OpenAI(temperature=0.7)
        self.api_client = APIClient(settings.DEFAULT_SERVER_TYPE)
        self.memory = ConversationBufferMemory(memory_key="chat_history")

    def create_chain(self):
        prompt = PromptTemplate(
            input_variables=["chat_history", "human_input", "api_data"],
            template="""
            You are a customer support representative for {business_name}. Your goal is to assist customers with empathy and professionalism. 
            Every response should be concise (under 400 tokens) and address the customer's query with clarity.

            Chat History:
            {chat_history}

            Human: {human_input}

            API Data: {api_data}

            Assistant: """
        )

        chain = LLMChain(
            llm=self.llm,
            prompt=prompt,
            memory=self.memory,
            verbose=True
        )

        return chain

    async def get_api_data(self, query):
        # This method will call various APIs based on the query
        # For now, we'll just return a placeholder
        return "API data placeholder"

    async def process_query(self, query: str, business_id: int):
        api_data = await self.get_api_data(query)
        chain = self.create_chain()
        response = chain.predict(human_input=query, api_data=api_data, business_name=settings.PROJECT_NAME)
        return response

support_chain = CustomerSupportChain()

# Define the graph
graph = Graph()

@graph.node
async def api_lookup(query):
    return await support_chain.get_api_data(query)

@graph.node
async def generate_response(query, api_data):
    chain = support_chain.create_chain()
    return chain.predict(human_input=query, api_data=api_data, business_name=settings.PROJECT_NAME)

# Connect the nodes
graph.add_edge(api_lookup, generate_response)

async def run_graph(query):
    result = await graph.arun({"query": query})
    return result["generate_response"]

