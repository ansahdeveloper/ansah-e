from fastapi import FastAPI
from app.api.v1 import api as api_v1
from app.api.v2 import api as api_v2
from app.core.rate_limit import RateLimitMiddleware

app = FastAPI()

app.add_middleware(RateLimitMiddleware)

app.include_router(api_v1.router, prefix="/api/v1")
app.include_router(api_v2.router, prefix="/api/v2")

