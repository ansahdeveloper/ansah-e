from fastapi import FastAPI
from fastapi.openapi.utils import get_openapi
from app.api.v1 import api as api_v1
from app.api.v2 import api as api_v2
from app.core.rate_limit import RateLimitMiddleware

app = FastAPI()

app.add_middleware(RateLimitMiddleware)

app.include_router(api_v1.router, prefix="/api/v1")
app.include_router(api_v2.router, prefix="/api/v2")

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Ansah E Backend API",
        version="1.0.0",
        description="API for Ansah E's AI-powered customer support system",
        routes=app.routes,
    )
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

