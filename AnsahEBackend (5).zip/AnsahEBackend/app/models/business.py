from sqlalchemy import Column, Integer, String, Text, JSON, Enum
from sqlalchemy.dialects.postgresql import ARRAY
from app.db.base import Base

class Business(Base):
    __tablename__ = "businesses"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    contact_email = Column(String, nullable=False)
    faq_url = Column(String)
    shipping_policy_url = Column(String)
    return_policy_url = Column(String)
    refund_policy_url = Column(String)
    business_phone = Column(String)
    social_media_links = Column(ARRAY(String))
    custom_api_url = Column(String)
    response_tone = Column(Enum('friendly', 'professional', 'empathetic', name='response_tone_enum'))

