from fastapi import APIRouter, Depends
from app.services.ai_service import AIService
from app.core.config import settings
from pydantic import BaseModel

router = APIRouter()

class QueryModel(BaseModel):
    user_query: str
    business_id: int

@router.post("/generate_response")
async def generate_response(query: QueryModel):
    ai_service = AIService(server_type=settings.DEFAULT_SERVER_TYPE)
    response = await ai_service.generate_response(query.user_query, query.business_id)
    return {"response": response}

