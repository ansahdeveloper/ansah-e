from redis import Redis
from app.core.config import settings

redis = Redis.from_url(settings.REDIS_URL)

def cache_set(key: str, value: str, expiration: int = 3600):
    return redis.set(key, value, ex=expiration)

def cache_get(key: str):
    return redis.get(key)

def cache_delete(key: str):
    return redis.delete(key)

