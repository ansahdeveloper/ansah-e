from circuitbreaker import circuit
from prometheus_client import Counter, Gauge

circuit_open = Gauge('circuit_breaker_open', 'Circuit Breaker Open Status', ['service'])
circuit_requests = Counter('circuit_breaker_requests', 'Circuit Breaker Requests', ['service', 'status'])

@circuit(failure_threshold=5, recovery_timeout=30)
async def call_external_service(service_name, service_func, *args, **kwargs):
    try:
        result = await service_func(*args, **kwargs)
        circuit_requests.labels(service=service_name, status='success').inc()
        circuit_open.labels(service=service_name).set(0)
        return result
    except Exception as e:
        circuit_requests.labels(service=service_name, status='failure').inc()
        circuit_open.labels(service=service_name).set(1)
        raise e

