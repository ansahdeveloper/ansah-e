from tenacity import retry, stop_after_attempt, wait_exponential_jitter, retry_if_exception_type
import httpx

@retry(
    stop=stop_after_attempt(5),
    wait=wait_exponential_jitter(multiplier=1, max=60),
    retry=retry_if_exception_type((httpx.ConnectTimeout, httpx.ReadTimeout, ConnectionError))
)
async def retry_async(func, *args, **kwargs):
    return await func(*args, **kwargs)

class AppException(Exception):
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail

def handle_app_exception(exc: AppException):
    raise HTTPException(status_code=exc.status_code, detail=exc.detail)

