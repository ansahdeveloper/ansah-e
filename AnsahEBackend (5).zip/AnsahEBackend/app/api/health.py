from fastapi import APIRouter
from app.core.cache import cache
from app.db.session import SessionLocal
import asyncio

router = APIRouter()

async def check_db_connection():
    db = SessionLocal()
    try:
        result = db.execute("SELECT 1").fetchone()
        latency = await measure_db_latency(db)
        return {"status": "healthy", "latency": latency}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}
    finally:
        db.close()

async def measure_db_latency(db):
    start = asyncio.get_event_loop().time()
    db.execute("SELECT 1")
    end = asyncio.get_event_loop().time()
    return end - start

async def check_redis_connection():
    try:
        cache.set("health_check", "1")
        value = cache.get("health_check")
        assert value == "1"
        return {"status": "healthy"}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}

@router.get("/health")
async def health_check():
    db_health = await check_db_connection()
    redis_health = await check_redis_connection()
    
    return {
        "status": "healthy" if db_health["status"] == "healthy" and redis_health["status"] == "healthy" else "unhealthy",
        "components": {
            "database": db_health,
            "redis": redis_health
        }
    }

