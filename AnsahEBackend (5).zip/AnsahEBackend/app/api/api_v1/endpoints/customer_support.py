from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.services.customer_support_chain import support_chain, run_graph
from app.core.logging import logger
from app.core.error_handling import AppException
from pydantic import BaseModel

router = APIRouter()

class Query(BaseModel):
    business_id: int
    user_query: str

@router.post("/query")
async def handle_query(query: Query, db: Session = Depends(get_db)):
    try:
        # response = await support_chain.process_query(query.user_query, query.business_id)
        response = await run_graph(query.user_query)
        logger.info(f"Query processed successfully for business {query.business_id}")
        return {"response": response}
    except AppException as e:
        logger.error(f"Application error: {str(e)}")
        raise HTTPException(status_code=e.status_code, detail=e.detail)
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        raise HTTPException(status_code=500, detail="An unexpected error occurred")

