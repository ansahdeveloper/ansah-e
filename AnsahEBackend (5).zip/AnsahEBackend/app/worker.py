from celery import Celery
from app.core.config import settings

celery = Celery(__name__)
celery.conf.broker_url = settings.REDIS_URL
celery.conf.result_backend = settings.REDIS_URL

@celery.task(name="send_email")
def send_email(to: str, subject: str, body: str):
    # Implement email sending logic here
    pass

@celery.task(name="process_order")
def process_order(order_id: int):
    # Implement order processing logic here
    pass

