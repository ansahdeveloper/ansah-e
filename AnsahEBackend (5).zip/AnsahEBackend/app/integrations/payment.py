from .api_client import api_client

class PayPalAPI:
    BASE_URL = "https://api.paypal.com/v1"

    async def get_payment_status(self, payment_id):
        return await api_client.get(f"{self.BASE_URL}/payments/payment/{payment_id}")

class StripeAPI:
    BASE_URL = "https://api.stripe.com/v1"

    async def get_payment_status(self, charge_id):
        return await api_client.get(f"{self.BASE_URL}/charges/{charge_id}")

# Add other payment APIs here

