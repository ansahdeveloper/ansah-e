from .api_client import api_client

class AlgoliaAPI:
    BASE_URL = "https://your-app-id.algolia.net/1/indexes/faqs"

    async def search_faqs(self, query):
        return await api_client.get(f"{self.BASE_URL}/query", params={"query": query})

class ZendeskHelpCenterAPI:
    BASE_URL = "https://your-domain.zendesk.com/api/v2/help_center"

    async def get_articles(self):
        return await api_client.get(f"{self.BASE_URL}/articles.json")

# Add other FAQ APIs here

