from .api_client import api_client

class ShopifyAPI:
    BASE_URL = "https://your-store.myshopify.com/admin/api/2021-10"

    async def get_products(self):
        return await api_client.get(f"{self.BASE_URL}/products.json")

class BigCommerceAPI:
    BASE_URL = "https://api.bigcommerce.com/stores/your-store-hash/v3"

    async def get_products(self):
        return await api_client.get(f"{self.BASE_URL}/catalog/products")

# Add other product catalog APIs here

