from .api_client import api_client

class ShippoAPI:
    BASE_URL = "https://api.goshippo.com/v1"

    async def track_shipment(self, tracking_number):
        return await api_client.post(f"{self.BASE_URL}/shipments/track", json={"tracking_number": tracking_number})

class EasyPostAPI:
    BASE_URL = "https://api.easypost.com/v2"

    async def track_shipment(self, tracking_number):
        return await api_client.post(f"{self.BASE_URL}/trackers", json={"tracking_code": tracking_number})

# Add other shipping APIs here

