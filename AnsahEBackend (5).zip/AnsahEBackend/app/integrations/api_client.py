import httpx
from app.core.config import settings
from app.core.error_handling import retry_async, AppException

class APIClient:
    def __init__(self, server_type: str):
        self.server_type = server_type
        self.base_url = settings.LOCAL_API_URL if server_type == 'local' else settings.CLOUD_API_URL

    async def get_model_response(self, prompt: str, server_type: str):
        try:
            async with httpx.AsyncClient() as client:
                response = await retry_async(
                    client.post,
                    f"{self.base_url}/generate",
                    json={"prompt": prompt, "server_type": server_type}
                )
                response.raise_for_status()
                return response.json().get("text", "")
        except httpx.HTTPStatusError as e:
            raise AppException(status_code=500, detail=f"Error generating response: {str(e)}")
        except Exception as e:
            raise AppException(status_code=500, detail=f"Unexpected error: {str(e)}")

