import httpx
from app.core.config import settings
from app.core.error_handling import retry_async, AppException

class APIClient:
    def __init__(self, server_type: str):
        self.server_type = server_type
        self.base_url = settings.LOCAL_API_URL if server_type == 'local' else settings.CLOUD_API_URL

    async def get_order_status(self, order_id: str):
        try:
            async with httpx.AsyncClient() as client:
                response = await retry_async(
                    client.get,
                    f"{self.base_url}/shopify/orders/{order_id}"
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            raise AppException(status_code=500, detail=f"Error fetching order status: {str(e)}")

    async def get_shipping_status(self, tracking_number: str):
        try:
            async with httpx.AsyncClient() as client:
                response = await retry_async(
                    client.get,
                    f"{self.base_url}/shipping/track/{tracking_number}"
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            raise AppException(status_code=500, detail=f"Error fetching shipping status: {str(e)}")

    async def verify_payment(self, order_id: str):
        try:
            async with httpx.AsyncClient() as client:
                response = await retry_async(
                    client.get,
                    f"{self.base_url}/payments/verify/{order_id}"
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            raise AppException(status_code=500, detail=f"Error verifying payment: {str(e)}")

    async def create_support_ticket(self, ticket_data: dict):
        try:
            async with httpx.AsyncClient() as client:
                response = await retry_async(
                    client.post,
                    f"{self.base_url}/zendesk/tickets",
                    json=ticket_data
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            raise AppException(status_code=500, detail=f"Error creating support ticket: {str(e)}")

